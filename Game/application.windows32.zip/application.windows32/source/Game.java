import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 
import interfascia.*; 
import ddf.minim.*; 
import java.util.Iterator; 
import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Game extends PApplet {

 //<>// //<>// //<>// //<>//




GUIController control;
IFButton button1;
Player player;
Projectiles projectiles;
/* I'm all about that*/Base /* 'bout that */  base; //no treble
EnemyHandler enemyHandler;
float timer, lastFire;
PImage bg;
int gameState;
int keyPress;
boolean keys[] = new boolean[5]; //array used by keyPressed(), keyReleased() and player.move()
ArrayList<ParticleSystem> ps;
ArrayList<Decal> decals;

AudioPlayer audio;
Minim minim;

public void setup() {
  projectiles = new Projectiles();
  control= new GUIController(this);
  button1 = new IFButton("Unpause", 1400, height/2);
  button1.addActionListener(this);
  control.add(button1);
  player = new Player(projectiles);
  enemyHandler = new EnemyHandler();
  base = new Base(new PVector(60, height/2));
  bg = new PImage();
  bg = loadImage("Sprites/Grey_Matters_Map.png");
  
  keys[0] = false;
  keys[1] = false;
  keys[2] = false;
  keys[3] = false;
  keys[4] = false;
  timer = 0;
  lastFire = 0;
  gameState = 0;
  keyPress = 0;
  cursor(CROSS);
  //enemyHandler.addEnemies(10, this.base);
  ps = new ArrayList<ParticleSystem>();
  decals = new ArrayList<Decal>();
  minim = new Minim(this);
  audio = minim.loadFile("Sound/track1.mp3");
  audio.loop();
}

public void draw() {
  clear();
  background(bg);
  fill(255, 255, 255);
  drawDecals();
  text(frameRate, 20, 140);
  base.drawBase();
  enemyHandler.drawEnemies();
  player.drawPlayer();
  projectiles.drawProjectiles();
  switch(gameState) {
  case 0:
    projectiles.update();
    button1.setX(1400);
    enemyHandler.spawnEnemies(1);
    player.move(keys);
    bulletHitCheck();
    particleHandler();
    endGame();
    //checks to see if the player can shoot a new projectile. The firerate decides how often the player can shoot.
    if (timer - lastFire >= player.getWeapon().getFireRate()) {
      if (player.shoot()) {
        lastFire = timer;
      }
    }
    break;
  case 1:
    
    button1.setX(width/2);
    break;
  case 2:
    text("Game over!", width/2, height/2);
    noLoop();
    break;
  }

  timer++;
}


public void drawDecals() {
  for (Decal d : decals) {
    d.drawDecal();
  }
}

public void addDecal(Decal d) {
  decals.add(d);
}
/**
 Collisiondetection used to check if two objects i.e enemy and base are close. 
 The method takes the PVectors for both objects and compares the X and Y values.
 Then the distance is calculated using pythagoras. If the distance is smaller than the sizes of the two objects togheter
 the method will return true.
 **/
public boolean collisionDetect(PVector location1, float size1, PVector location2, float size2) {

  float distX, distY, distance;
  distX = location1.x - location2.x;
  distY = location1.y - location2.y;
  distance = sqrt(pow(distX, 2) + pow(distY, 2));

  if (distance < size1/2 + size2/2) {
    return true;
  }
  return false;
}

/**
 Loops through the arraylists containing projectiles and enemies 
 and checks if any of the enemies have been hit by a bullet.
 The method uses the collisionDetection() method to do this
 and removes any bullets that have hit an enemy and sets the isDead 
 boolean flag in the enemy class to true. The method also adds a particle
 effect to the dead enemies
 **/
public void bulletHitCheck() {
  ArrayList<Projectile> pList = projectiles.getProjectiles();
  ArrayList<Enemy> enemies = enemyHandler.getEnemies();

  Iterator<Projectile> itP = pList.iterator();
  Iterator<Enemy> itE = enemies.iterator();

  for (itE = enemies.iterator(); itE.hasNext(); ) {
    Enemy enemy = itE.next();
    for (itP = pList.iterator(); itP.hasNext(); ) {
      Projectile bullet = itP.next();
      if (collisionDetect(bullet.getLocation(), bullet.getSize(), enemy.getLocation(), enemy.getSize())) {
        // enemy.die();
        ps.add(new ParticleSystem(enemy.getLocation(), 1.0f, 0.2f, 2, null, 1.0f));
        itP.remove();
        enemy.takeDamage(1);
        if(enemy.getHealth() <= 0){
        enemy.setDeath();
        }
      }
    }
  }
}

/**
 Loops through Particlesystem arraylist, removes dead particles and renders the ones 
 that lives.
 **/
public void particleHandler() {
  Iterator<ParticleSystem> it;

  for (it = ps.iterator(); it.hasNext(); ) {
    ParticleSystem p = it.next();
    if (p.isDead()) {
      it.remove();
    }
  }
  for (ParticleSystem p : ps) {
    p.render();
  }
}
/**
 Checks to see if any keys are pressed
 **/
public void keyPressed() {
  if (key == 'w' || key == 'W') {
    keys[0] = true;
  }

  if (key == 's' || key == 'S') {
    keys[1] = true;
  }

  if (key == 'd' || key == 'D') {
    keys[2] = true;
  }

  if (key == 'a' || key == 'A') {
    keys[3] = true;
  }
  if (key == 'p' || key == 'P') {
    keys[4] = true;
  }
}
/**
 Checks to see if the keys that have been pressed are released.
 **/
public void keyReleased() {
  if (key == 'w' || key == 'W') {
    keys[0] = false;
  }

  if (key == 's' || key == 'S') {
    keys[1] = false;
  }

  if (key == 'd' || key == 'D') {
    keys[2] = false;
  }

  if (key == 'a' || key == 'A') {
    keys[3] = false;
  }
  if (key == 'p' || key == 'P') {
    if ( keyPress == 0) {
      gameState = 1;
      keyPress = 1;
      audio.mute();
    } else if (keyPress == 1) {
      gameState = 0;
      keyPress = 0;
      audio.unmute();
    }
  }
  if (key == 'r' || key == 'R') {
    reset();
    redraw();
    loop();
  }
  if (key == 'q' || key == 'Q') {
    player.cycleWeaponDown();
  }
  if (key == 'e' || key == 'E') {
    player.cycleWeaponUp();
  }
}  
public void endGame() {
  if (base.getHealth() <= 0) {
    gameState = 2;
    audio.mute();
  }
}
public void actionPerformed (GUIEvent e) {
  if (e.getSource() == button1) {
    gameState = 0;
    keyPress = 0;
    audio.unmute();
  }
}
public void reset() {
  timer = 0;
  lastFire = 0;
  gameState = 0;
  keyPress = 0;
  ps.clear();
  decals.clear();
  enemyHandler.clearEnemies();
  base.setHealth(10);
  audio.loop();
}
/*
static public void main(String args[]) {
 PApplet.main("Game");
 }*/
class AssaultRifle implements Weapon {
  ArrayList<Projectile> pList;
  Player player;
  private float oldPosX, oldPosY, rotation, size, fireRate;
  int weaponID;
  PImage sprite;
  AssaultRifle(ArrayList<Projectile> pList, Player player) {
    this.pList = pList;
    fireRate = 15;
    this.player = player;
    weaponID = 1;
    sprite = loadImage("Sprites/Player_AK.png");
  }

  public void shoot() {
    size = 10.0f;
    oldPosX = mouseX;
    oldPosY = mouseY;
    PVector location= new PVector(player.playPos.x, player.playPos.y);
    rotation = atan2(oldPosY - location.y, oldPosX - location.x) / PI * 180;
    pList.add(new Projectile(player, rotation, size));
  }
  public void secondaryFire() {
  }
  public float getFireRate() {
    return fireRate;
  }
  public int getWeaponID() {
    return weaponID;
  }
  public PImage getSprite(){
    return sprite;
  }
}

class Base {
  PImage[] sprites;
  PVector pos;
  int health;
  float size;
  public Base(PVector position) {
    this.pos = position;
    this.size = 50.0f;
    imageMode(CENTER);
    health = 10;
    sprites = new PImage[10];
    //Adds all the different base-sprites to an array that drawBase uses.
    for(int i = 1; i <= 9; i++){
     sprites[i-1] = loadImage("Sprites/Grey_Matters_Core_" + i + "_Health.png");
    }
    sprites[9] = loadImage("Sprites/Grey_Matters_Core_Full_Health_Bigger.png");
  }
  /**
  draws the base in different states, depending on the health of the base.
  **/
  public void drawBase() {
    text("Base health: " + health, 20, 100);
     switch(health){
    case 1: 
            image(sprites[0], pos.x, pos.y);
            break;
    case 2:
            image(sprites[1], pos.x, pos.y);
            break;
    case 3: 
            image(sprites[2], pos.x, pos.y);
            break;
    case 4: 
            image(sprites[3], pos.x, pos.y);
            break;
    case 5: 
            image(sprites[4], pos.x, pos.y);
            break;
    case 6: 
            image(sprites[5], pos.x, pos.y);
            break;
    case 7: 
            image(sprites[6], pos.x, pos.y);
            break;
    case 8: 
            image(sprites[7], pos.x, pos.y);
            break;        
    case 9: 
            image(sprites[8], pos.x, pos.y);
            break;
    case 10: 
             image(sprites[9], pos.x, pos.y);
             
    default:
   
    
    }
  }
  //Getter for the X position of the base
  public float getPosX(){  
    return this.pos.x;
  }
  //Getter for the Y position of the base
  public float getPosY(){  
    return this.pos.y;
  }
  //Getter for the  position of the base
  public PVector getLocation(){
    return this.pos;
  }
  //Getter for the size of the base
  public float getSize(){
    return size;
  }
   //Getter for the  health of the base
  public int getHealth(){
    return this.health;
   }
   /**
   Method used for damaging the base.
   This method is called when the enemy //<>// //<>//
   crashes into the base.
   **/
   public void takeDamage(int dmg){
     this.health = this.health - dmg; //<>//
   }
   public void setHealth(int newHealth){
     health = health + newHealth;
   }
}
class Decal{
PVector pos;
PImage img;
PVector rgb;
  
  
 public Decal(PImage sprite, PVector position, PVector tint){
   this.pos = position;
   this.img = sprite;
   this.rgb = tint;
 }
  
  public PVector getPos(){
   return pos; 
  }
  
  public PImage getSprite(){
   return img; 
  }
  
  public PVector getColor(){
    return rgb;
  }
  
  public void drawDecal(){
   tint(rgb.x, rgb.y, rgb.z);
   image(img, pos.x, pos.y); 
   noTint();
  }
  
  
}
/*
/ Parentklasse til fiende. Alle fiender vil extende denne klassen
 */

class Enemy {

  private float health, size, rotation, oldPosX, oldPosY, speed, aniTimer;
  PImage[] sprite;
  EnemyHandler eh;
  private PVector pos;
  boolean isDead;
  Base base;
  PImage[] decals;
  PVector[] colors;
  public Enemy( Base base, EnemyHandler eh) {
    this.eh = eh;
    this.base = base;
    sprite = new PImage[2];
    sprite[0] = loadImage("Sprites/Grey_Matters_Medium_enemy_Part1.png");
    sprite[1] = loadImage("Sprites/Grey_Matters_Medium_enemy_Part2.png");
    this.pos = new PVector(1280.0f, random(960));
    this.oldPosX = pos.x;
    this.oldPosY = pos.y;
    this.rotation = atan2(oldPosY - base.getPosY(), oldPosX - base.getPosX()) / PI * 180;
    this.speed = -2.5f; // speed is negative since the enemies move "backwards" on the X-axis
    size = 60.0f;
    this.isDead = false;
    decals = new PImage[3];
    health = 3;
    for(int i = 1; i <= 3; i++){
     decals[i-1] = loadImage("Sprites/Grey_Matters_Splatt" + i + ".png");
    }
    imageMode(CENTER);
    aniTimer = 0;
    
    colors = new PVector[25];
    for(int i = 0; i < 25; i++){
      colors[i] = new PVector();
    }
    colors[0].set(255.0f, 0.0f, 0.0f);
    colors[1].set(255.0f, 64.0f, 0.0f);
    colors[2].set(255.0f, 128.0f, 0.0f);
    colors[3].set(255.0f, 191.0f, 0.0f);
    colors[4].set(255.0f, 255.0f, 0.0f);
    colors[5].set(191.0f, 255.0f, 0.0f);
    colors[6].set(128.0f, 255.0f, 0.0f);
    colors[7].set(64.0f, 255.0f, 0.0f);
    colors[8].set(0.0f, 255.0f, 0.0f);
    colors[9].set(0.0f, 255.0f, 64.0f);
    colors[10].set(0.0f, 255.0f, 128.0f);
    colors[11].set(0.0f, 255.0f, 191.0f);
    colors[12].set(0.0f, 255.0f, 255.0f);
    colors[13].set(0.0f, 191.0f, 255.0f);
    colors[14].set(0.0f, 128.0f, 255.0f);
    colors[15].set(0.0f, 64.0f, 255.0f);
    colors[16].set(0.0f, 0.0f, 255.0f);
    colors[17].set(64.0f, 0.0f, 255.0f);
    colors[18].set(128.0f, 0.0f, 255.0f);
    colors[19].set(191.0f, 0.0f, 255.0f);
    colors[20].set(255.0f, 0.0f, 255.0f);
    colors[21].set(255.0f, 0.0f, 191.0f);
    colors[22].set(255.0f, 0.0f, 128.0f);
    colors[23].set(255.0f, 0.0f, 64.0f);
    
  }
  //draws the enemy
  public void drawEnemy() {
    
    if(aniTimer < 30){
     image(sprite[0], pos.x, pos.y); 
    }
    else if(aniTimer >= 30 && aniTimer <= 60){
      image(sprite[1], pos.x, pos.y);
    }
    else{
      image(sprite[1], pos.x, pos.y);
      aniTimer = 0;
      
    }
    aniTimer++;
  }
  /**
  Move method for the enemy class. This method moves the enemy towards the base
  while constantly checking collisionDetect() to see of the enemy has crashed into the base.
  If the enemy crashes into the base, the base takes damage and the boolean flag isDead is
  set to true by the setDeath method.
  **/
  public void move() {
    if (collisionDetect( pos, size, base.getLocation(), base.getSize()) ) { //<>//
      base.takeDamage(1); //<>//
      setDeath();
    } else {
      pos.x = pos.x + cos(rotation/180*PI)*speed;
      pos.y = pos.y + sin(rotation/180*PI)*speed;
    }
  }
  //Getter for the location of the enemy
  public PVector getLocation() {
    return pos;
  }
  //Getter for the size of the enemy
  public float getSize() {
    return size;
  }
  //This method is currently not in use
  public void die() {
    Decal d = new Decal(decals[PApplet.parseInt(random(0, 2))], pos, colors[PApplet.parseInt(random(0,22))]);
    addDecal(d);
  }
  //Getter for the isDead boolean flag 
  public boolean isDead() {
    return isDead;
  }
  public void takeDamage(int weaponDamage){
      health = health - weaponDamage;
  }
  // Sets the isDead boolean flag to true
  // Removes the enemy from screen next frame
  public void setDeath() {
    isDead = true;
    die();
  }
  public float getHealth(){
    return health;
  }
}
class EnemyHandler {
  ArrayList<Enemy> enemies;
  float timer, spawnRate, timeSinceLast;
  public EnemyHandler() {
    enemies = new ArrayList<Enemy>();
    this.spawnRate = 200.0f; //hardkoda verdi menst eg testa
    this.timer = 0;
  }
  public void addEnemies(int enemyNum, Base base) {
    for (int i = 0; i < enemyNum; i++) {
      enemies.add(new Enemy(base, this));
    }
  }
  public void spawnEnemies(int enemyWave) {

    if (timer - timeSinceLast >= spawnRate) {
      addEnemies(enemyWave, base);
      timeSinceLast = timer;
    }
    removeDeadEnemy();
    for (Enemy e : enemies) {
      e.move();
    }
    timer++;
  }

  public ArrayList<Enemy> getEnemies() {
    return enemies;
  }
  public void drawEnemies() {
    for (Enemy e : enemies) {
      e.drawEnemy();
    }
  }
  public void removeDeadEnemy() {
    Iterator<Enemy> it;

    for (it = enemies.iterator(); it.hasNext(); ) {
      Enemy e = it.next();
      if (e.isDead()) {
        it.remove();
      }
    }
  }
  public void clearEnemies(){
    enemies.clear();
  }
}
/**
Represents one particle
**/

class Particle{
  PVector position;
  PVector velocity;
  PVector rgb;
  float lifeTime;
  float size;
  ParticleSystem system;
  PVector sysOrigin;
  boolean dead;
  float timer;
  float opacity;
 
  /**
  Constructor for Particle class
  Creates a particle belonging to a certain particle system,
  the particle has its own Position (relative to the system),
  velocity, color, lifetime and size.
  **/
  public Particle(ParticleSystem sys, PVector pos, PVector velocity, PVector rgb, float lifeTime, float size){
    system = sys;
    this.velocity = velocity;
    this.rgb = rgb;
    this.lifeTime = lifeTime;
    this.size = size;
    sysOrigin = system.getPosition();
    position = PVector.add(sysOrigin, pos);
    dead = false;
    timer = 0;
    opacity = 255.0f;
  }
  
  
  /**
  Particle Logic
  Updates position, color, and flags particle as dead if
  lifetime has been exceeded.
  **/
   public void update() {
    noStroke();
    fill(rgb.x, rgb.y, rgb.z, opacity);
    
    ellipse(position.x + velocity.x, position.y + velocity.y, size, size);
    stroke(1);
    fill(255, 255, 255);
    position = PVector.add(position, velocity);
    if(timer > lifeTime){
     dead = true; 
    }
    timer++;
    opacity = lerp(opacity, 0, opacity/(lifeTime*20));
  }
  
  /**
  Getter for dead value
  **/
  public boolean isDead(){
   return dead; 
  }
}
/**
A particle system is a collection of particles
It has a position, a rate at which it fires particles and a lifetime
**/

class ParticleSystem{
  ArrayList<Particle> particles;
  PVector position;
  float rate;
  float radius;
  float timer;
  float timeSinceLast;
  float lifeTime;
  float pLife;
  boolean dead;
  float speedFactor;
  PVector rgb;
  PVector[] colors;
  
  /**
  Constructor for ParticleSystem
  Creates a particle system with a given position, rate, and duration.
  Color, speed and lifetime of particles also needs to be defined.
  **/
  public ParticleSystem(PVector pos, float rate, float duration, float speedMultiplier, PVector rgb, float pLife){
    this.pLife = pLife * 60;
    position = pos;
    speedFactor = speedMultiplier;
    lifeTime = duration * 60;
    this.rate = rate;
    particles = new ArrayList<Particle>();
    dead = false;
    if(rgb == null){
      colors = new PVector[25];
      for(int i = 0; i < 24; i++){
        colors[i] = new PVector();
      }
      colors[0].set(255.0f, 0.0f, 0.0f);
      colors[1].set(255.0f, 64.0f, 0.0f);
      colors[2].set(255.0f, 128.0f, 0.0f);
      colors[3].set(255.0f, 191.0f, 0.0f);
      colors[4].set(255.0f, 255.0f, 0.0f);
      colors[5].set(191.0f, 255.0f, 0.0f);
      colors[6].set(128.0f, 255.0f, 0.0f);
      colors[7].set(64.0f, 255.0f, 0.0f);
      colors[8].set(0.0f, 255.0f, 0.0f);
      colors[9].set(0.0f, 255.0f, 64.0f);
      colors[10].set(0.0f, 255.0f, 128.0f);
      colors[11].set(0.0f, 255.0f, 191.0f);
      colors[12].set(0.0f, 255.0f, 255.0f);
      colors[13].set(0.0f, 191.0f, 255.0f);
      colors[14].set(0.0f, 128.0f, 255.0f);
      colors[15].set(0.0f, 64.0f, 255.0f);
      colors[16].set(0.0f, 0.0f, 255.0f);
      colors[17].set(64.0f, 0.0f, 255.0f);
      colors[18].set(128.0f, 0.0f, 255.0f);
      colors[19].set(191.0f, 0.0f, 255.0f);
      colors[20].set(255.0f, 0.0f, 255.0f);
      colors[21].set(255.0f, 0.0f, 191.0f);
      colors[22].set(255.0f, 0.0f, 128.0f);
      colors[23].set(255.0f, 0.0f, 64.0f);
      this.rgb = colors[PApplet.parseInt(random(0, 23))];
    }
    else{
      this.rgb = rgb;
    }
    
    

    }
  
  /**
  Handles the logic of the particle system.
  **/
  public void render(){
   //Check if it's time to spawn a new particle.
   if(timer - timeSinceLast >= rate){
     particles.add(new Particle(this, new PVector(random(-radius/2, radius/2), random(-radius/2, radius/2)), new PVector(random(-2,2), random(-2,2)).mult(speedFactor) , new PVector(rgb.x, rgb.y, rgb.z), pLife, 7.0f));
     timeSinceLast = timer;
   }
   //Clear dead particles from the draw list
   removeDeadParticles();
   
   //Update all particles
   for(Particle p : particles){
    p.update();
   }
   
   //If the particle systems duration has run out, flag as dead and remove particles
   if(timer > lifeTime){
    particles = null;
    dead = true;
   }
   
    timer++;
  }
  
  /**
  Gets the list of particles
  **/
  public ArrayList<Particle> getParticles(){
   return particles; 
  }
  
  
  /**
  Gets the radius of the system
  **/
  public float getRadius(){
   return radius; 
  }
  
  
  /**
  Gets the position of the system as a PVector
  **/
  
  public PVector getPosition(){
   return position; 
  }
  
  /**
  Checks if the system is dead
  Returns true if it is.
  
  **/
  public boolean isDead(){
   return dead; 
  }
  
  
  /**
  Removes all particles that are flagged as dead
  **/
  public void removeDeadParticles(){
  Iterator<Particle> it;
  
  for(it = particles.iterator();it.hasNext();){
    Particle p = it.next();
    if(p.isDead()){
     it.remove(); 
    }
  }
}
}
class Pistol implements Weapon{
  ArrayList<Projectile> pList;
  Player player;
  private float oldPosX, oldPosY, rotation, size, fireRate;
  int weaponID;
  PImage sprite;
  Pistol(ArrayList<Projectile> pList, Player player){
    this.pList = pList;
    fireRate = 30;
    this.player = player;
    weaponID = 0;
    sprite = loadImage("Sprites/Player_gun.png");
  }
  
  public void shoot(){
    size = 10.0f;
    oldPosX = mouseX;
    oldPosY = mouseY;
    PVector location= new PVector(player.playPos.x ,player.playPos.y);
    rotation = atan2(oldPosY - location.y, oldPosX - location.x) / PI * 180;
    pList.add(new Projectile(player, rotation, size));
  }
  public void secondaryFire(){
  }
  public float getFireRate(){
   return fireRate;
 }
  public int getWeaponID(){
    return weaponID;
  }
  public PImage getSprite(){
    return sprite;
  }
}
class Player {
  float stepSize;
  PImage sprite;
  PVector playPos, velocity;
  int weaponState;
  float timer, fireRate, fireMod;
  ArrayList<Weapon> weapons;
  Weapon weapon;
  public Player(Projectiles projectiles) {
    timer = 0;  
    this.playPos = new PVector(500, 500);
    this.stepSize = 2;
    fireMod = 1.0f;
    weaponState = 1;
    weapons = new ArrayList<Weapon>();
    weapons.add(new Pistol(projectiles.getProjectiles(), this));
    weapons.add(new AssaultRifle(projectiles.getProjectiles(), this));
    weapons.add(new Shotgun(projectiles.getProjectiles(), this));
    weapon = weapons.get(0);
    sprite = weapon.getSprite();
  }
  public PVector getPlayPos() {
    return this.playPos;
  }
  public void setPlayerX(float newX) {
    playPos.x = newX;
  }
  public void setPlayerY(float newY) {
    playPos.y = newY;
  }

  public void drawPlayer() {
    imageMode(CENTER);
    rectMode(CENTER);
    // rect(playPos.x, playPos.y, 20.0, 20.0);
    text("Player X: " + playPos.x + "  Player y: "  + playPos.y, 20, 60);
    text("Mouse x: " + mouseX + "  Mouse y: " + mouseY, 20, 20);

    float rot = getAngle(playPos, new PVector(mouseX, mouseY));

    text("Angle: " + degrees(rot), 20, 40);

    pushMatrix();

    translate(playPos.x, playPos.y);
    if (gameState == 0) {
      rotate(rot);
    }
    // translate(width/2, height/2);
    image(sprite, 20, 0);
    popMatrix();
  }

  public void move(boolean keys[]) {
    if (keys[0]) {
      playPos.y = constrain(playPos.y - stepSize, 20, height-20);
    }
    if (keys[1]) {
      playPos.y = constrain(playPos.y + stepSize, 20, height-20);
    }
    if (keys[2]) {
      playPos.x = constrain(playPos.x + stepSize, 20, width-20);
    }
    if (keys[3]) {
      playPos.x = constrain(playPos.x - stepSize, 20, width-20);
    }
  }

  public boolean shoot() {
    if (mousePressed && (mouseButton == LEFT)) {
      weapon.shoot();
      return true;
    } else if (mousePressed && (mouseButton == RIGHT)) {
      //Special attacks?
      return false;
    }
    return false;
  }


  public float getAngle(PVector v1, PVector v2) {

    float dy = v2.y - v1.y;
    float dx = v2.x - v1.x;

    return atan2(dy, dx);
  }

  public void cycleWeaponUp() {
    for (Weapon w : weapons) {
      if (w.getWeaponID() > weapon.getWeaponID()) {
        weapon = w;
        sprite = weapon.getSprite();
        break;
      }
    }
  }

  public void cycleWeaponDown() {
    for ( int i = weapons.size() - 1; i>=0; i--) {
      if (weapons.get(i).getWeaponID() < weapon.getWeaponID()) {
        weapon = weapons.get(i);
        sprite = weapon.getSprite();
        break;
      }
    }
  }

  public Weapon getWeapon() {
    return weapon;
  }
}
class Projectile {
  //standard PVector used for the location of the bullet
  private PVector location;
  private PVector rgb;
  boolean isDead;
  //vars used to check the angle between location and the mouse
  float speed, rotation, size, oldPosX, oldPosY;
  PVector[] colors;

  public Projectile(Player player, float rotation, float size) {
    this.isDead = false;
    colors = new PVector[25];
    oldPosX = mouseX;
    oldPosY = mouseY;
    PVector offset = new PVector(oldPosX - player.playPos.x, oldPosY - player.playPos.y);
    offset = PVector.mult(offset, 0.1f);
    location = new PVector(player.playPos.x + offset.x, player.playPos.y + offset.y);
    this.rotation = rotation;
    this.size = size;
    for (int i = 0; i < 25; i++) {
      colors[i] = new PVector();
    }
    colors[0].set(255.0f, 0.0f, 0.0f);
    colors[1].set(255.0f, 64.0f, 0.0f);
    colors[2].set(255.0f, 128.0f, 0.0f);
    colors[3].set(255.0f, 191.0f, 0.0f);
    colors[4].set(255.0f, 255.0f, 0.0f);
    colors[5].set(191.0f, 255.0f, 0.0f);
    colors[6].set(128.0f, 255.0f, 0.0f);
    colors[7].set(64.0f, 255.0f, 0.0f);
    colors[8].set(0.0f, 255.0f, 0.0f);
    colors[9].set(0.0f, 255.0f, 64.0f);
    colors[10].set(0.0f, 255.0f, 128.0f);
    colors[11].set(0.0f, 255.0f, 191.0f);
    colors[12].set(0.0f, 255.0f, 255.0f);
    colors[13].set(0.0f, 191.0f, 255.0f);
    colors[14].set(0.0f, 128.0f, 255.0f);
    colors[15].set(0.0f, 64.0f, 255.0f);
    colors[16].set(0.0f, 0.0f, 255.0f);
    colors[17].set(64.0f, 0.0f, 255.0f);
    colors[18].set(128.0f, 0.0f, 255.0f);
    colors[19].set(191.0f, 0.0f, 255.0f);
    colors[20].set(255.0f, 0.0f, 255.0f);
    colors[21].set(255.0f, 0.0f, 191.0f);
    colors[22].set(255.0f, 0.0f, 128.0f);
    colors[23].set(255.0f, 0.0f, 64.0f);
    speed = 10;
    rgb = colors[PApplet.parseInt(random(0, 23))];
  }
  public void update() {
    //move the bullet
    location.x = location.x + cos(rotation/180*PI)*speed;
    location.y = location.y + sin(rotation/180*PI)*speed;

    //removes the bullet from the arrayList if it is off the room
    if (location.x > 0 && location.x< width && location.y > 0 && location.y < height ) {
    } else {
      setDeath();
    }
  }
  public void drawProjectile() {
    fill(rgb.x, rgb.y, rgb.z);
    ellipse(location.x, location.y, size, size);
    fill(255, 255, 255);
  }
  public PVector getLocation() {
    return location;
  }

  public float getSize() {
    return size;
  }

  public void destroy() {
    size = 0;
  }
  public void setDeath() {
    isDead = true;
  }
  public boolean isDead() {
    return isDead;
  }
}
class Projectiles {
  ArrayList<Projectile> projectiles;
  Projectiles() {
    projectiles = new ArrayList<Projectile>();
  }

  public void update() {
    for (int i  = projectiles.size()-1; i >= 0; i--) {
      Projectile projectile = projectiles.get(i);
      projectile.update();
    }
    removeProjectile();
  }
  public void drawProjectiles() {
    for (Projectile p : projectiles) {
      p.drawProjectile();
    }
  }
  public ArrayList<Projectile> getProjectiles() {
    return projectiles;
  }
  public void removeProjectile() {
    Iterator <Projectile> it;
    for (it = projectiles.iterator(); it.hasNext(); ) {
      Projectile p = it.next();
      if (p.isDead()) {
        it.remove();
      }
    }
  }
}
class Shotgun implements Weapon {
  ArrayList<Projectile> pList;
  Player player;
  private float oldPosX, oldPosY, rotation, size, fireRate;
  int weaponID;
  PImage sprite;
  Shotgun(ArrayList<Projectile> pList, Player player) {
    this.pList = pList;
    fireRate = 60;
    this.player = player;
    weaponID = 2;
    sprite = loadImage("Sprites/Player_Shotgun.png");

  }

  public void shoot() {
    size = 7.0f;
    oldPosX = mouseX;
    oldPosY = mouseY;
    PVector location= new PVector(player.playPos.x, player.playPos.y);
    rotation = atan2(oldPosY - location.y, oldPosX - location.x) / PI * 180;
    for (int i=0; i<5; i++) {
      float tempRot = rotation + (random(-10, 10)* PI/2);
      pList.add(new Projectile(player, tempRot, size));
    }
  }
  public void secondaryFire() {
  }
  public float getFireRate() {
    return fireRate;
  }
  public int getWeaponID(){
    return weaponID;
  }
  public PImage getSprite(){
    return sprite;
  }
}
interface Weapon{

  public void shoot();
  
  public void secondaryFire();

  public float getFireRate();
  
  public int getWeaponID();
  
  public PImage getSprite();

}
  public void settings() {  size(1280, 960); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "Game" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
